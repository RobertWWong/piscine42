/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astrole <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/28 18:26:13 by astrole           #+#    #+#             */
/*   Updated: 2018/01/28 18:26:15 by astrole          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>

void	ft_putstr(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		write(1, &str[i], 1);
	}
}

void	ft_strcat(char *s1, char *s2)
{
	int i;
	int pos;

	pos = 0;
	i = 0;
	while (s1[pos] != '\0')
		pos++;
	while (s2[i] != '\0')
	{
		s1[pos] = s2[i];
		i++;
		pos++;
	}
	s1[pos] = '\0';
}

int		ft_strcmp(char *s1, char *s2)
{
	int i;

	i = 0;
	while (s1[i] != '\0' && s2[i] != '\0')
	{
		if (s1[i] != s2[i])
			return (0);
	}
	if (s1[i] != '\0' || s2[i] != '\0')
		return (0);
	return (1);
}

int		type_check(char *str, int *x, int *y, int iter)
{
	if (str[0] == 'o')
	{
		iter = 1;
		while (str[iter] == '-')
		{
			iter++;
			*x += 1;
		}
		if (str[iter] == 'o' && str[iter + 1] == '\n')
		{
			iter += 2;
			while (str[iter] == '|' || str[iter] == ' ' || str[iter] == '\n')
				if (str[iter++] == '\n')
					*y += 1;
			if (str[iter] == 'o')
			{
				while (str[iter] == '-')
					iter++;
				if (str[iter] == 'o')
					return (1);
			}
		}
	}
	return (0);
}

int		main(void)
{
	size_t	nread;
	char	temp[1024];
	char	buffer[10000];
	int		x;
	int		y;

	buffer[0] = '\0';
	temp[0] = '\0';
	while ((nread = read(0, temp, sizeof(temp) - 1)) > 0)
	{
		temp[nread] = '\0';
		ft_strcat(buffer, temp);
	}
	x = 2;
	y = 2;
	printf("%s\n", buffer);
	printf("%d\n", type_check(buffer, &x, &y, 1));
    printf("[rush-00] [%d] [%d]\n", x, y);
	//printf("%d %d\n", x, y);
	return (0);
}
