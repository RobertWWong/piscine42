/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: astrole <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/14 18:54:05 by astrole           #+#    #+#             */
/*   Updated: 2018/01/14 18:54:07 by astrole          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

const char g_letters[3] = "o|-";

void	ft_putchar(char ch);

void	top_and_bottom(int x)
{
	int i;

	i = 0;
	ft_putchar(g_letters[0]);
	while (i < x)
	{
		ft_putchar(g_letters[2]);
		i++;
	}
	if (x > -1)
		ft_putchar(g_letters[0]);
	ft_putchar('\n');
}

void	middle(int x, int y)
{
	int j;
	int i;

	j = 0;
	while (j < y)
	{
		i = 0;
		ft_putchar(g_letters[1]);
		while (i < x)
		{
			ft_putchar(' ');
			i++;
		}
		if (x > -1)
			ft_putchar(g_letters[1]);
		ft_putchar('\n');
		j++;
	}
}

void	rush(int x, int y)
{
	if (x > 0 && y > 0)
	{
		x -= 2;
		y -= 2;
		top_and_bottom(x);
		if (y > -1)
		{
			middle(x, y);
			top_and_bottom(x);
		}
	}
}
