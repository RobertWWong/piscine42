/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_create_elem.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rowong <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/24 11:31:40 by rowong            #+#    #+#             */
/*   Updated: 2018/01/24 11:31:43 by rowong           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

t_list		*ft_create_elem(void *data)
{
	t_list	*linked_list;

	linked_list = (t_list *)malloc(sizeof(t_list) * 1);
	linked_list->data = data;
	linked_list->next = NULL;
	return (linked_list);
}
