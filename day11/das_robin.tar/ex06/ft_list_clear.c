/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_clear.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rowong <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/24 17:18:41 by rowong            #+#    #+#             */
/*   Updated: 2018/01/24 17:19:05 by rowong           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

void	ft_list_clear(t_list **begin_list)
{
	t_list *tmp;
	t_list *dele;

	tmp = *begin_list;
	while(tmp->next != NULL)
	{
		dele = tmp;
		tmp = tmp->next;
		free (dele);
	}
	free (tmp);
	*begin_list = NULL;
}
