/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_size.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rowong <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/01/24 15:27:25 by rowong            #+#    #+#             */
/*   Updated: 2018/01/24 15:31:22 by rowong           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

int		ft_list_size(t_list *begin_list)
{
	int		cnt;
	t_list	*tmp;

	cnt = 0;
	tmp = begin_list;
	if (tmp == 0)
		return (cnt);
	cnt++;
	while (tmp->next != 0)
	{
		cnt++;
		tmp = tmp->next;
	}
	return (cnt);
}
